// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
/**
 * Search the web and retrieve content for selected results.
 */
export class Providers extends APIResource {
    /**
     * Lists providers, capabilities, and machine-readable native-option schemas. Auto
     * and fallback are strategies, not provider entries. The list is not paginated and
     * contains no latency benchmarks. X-Request-Id identifies the request.
     *
     * @example
     * ```ts
     * const providers = await client.search.providers.list();
     * ```
     */
    list(query = {}, options) {
        return this._client.get('/search/providers', { query, ...options });
    }
}
//# sourceMappingURL=providers.mjs.map