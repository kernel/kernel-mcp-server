"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Contents = void 0;
const resource_1 = require("../../core/resource.js");
const path_1 = require("../../internal/utils/path.js");
/**
 * Search the web and retrieve content for selected results.
 */
class Contents extends resource_1.APIResource {
    /**
     * Retrieves selected results from a retained search. Provide exactly one of
     * result_ids or limit; the latter fetches the top results. Content defaults to
     * source:auto. Responses preserve result_ids order. Unknown result IDs are
     * rejected before retrieval starts. Missing, expired, or inaccessible searches
     * return 404. Once retrieval begins, return one outcome per selected result,
     * including timeout entries for work unfinished at the overall deadline. Browser
     * retrievals run sequentially in result order, so later results may time out when
     * earlier pages are slow. X-Request-Id identifies this request separately from the
     * search resource.
     *
     * @example
     * ```ts
     * const response = await client.search.contents.fetch(
     *   'srch_abc123',
     * );
     * ```
     */
    fetch(id, body, options) {
        return this._client.post((0, path_1.path) `/search/${id}/contents`, { body, ...options });
    }
}
exports.Contents = Contents;
//# sourceMappingURL=contents.js.map