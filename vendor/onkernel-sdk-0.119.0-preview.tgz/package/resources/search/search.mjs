// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as ContentsAPI from "./contents.mjs";
import { Contents as ContentsAPIContents } from "./contents.mjs";
import * as ProvidersAPI from "./providers.mjs";
import { Providers } from "./providers.mjs";
import { path } from "../../internal/utils/path.mjs";
/**
 * Search the web and retrieve content for selected results.
 */
export class SearchResource extends APIResource {
    constructor() {
        super(...arguments);
        this.contents = new ContentsAPI.Contents(this._client);
        this.providers = new ProvidersAPI.Providers(this._client);
    }
    /**
     * Returns ranked results from one serving provider. The default strategy selects a
     * provider that supports the requested options. The fallback strategy tries
     * providers in the supplied order. Results are not blended across providers.
     * Portable filters may be approximated or omitted according to provider
     * capabilities; warnings describe those outcomes unless strict_params is true.
     * Native options apply only to their selected provider.
     *
     * @example
     * ```ts
     * const search = await client.search.create({ query: 'x' });
     * ```
     */
    create(body, options) {
        return this._client.post('/search', { body, ...options });
    }
    /**
     * Returns the retained search resource exactly as it was returned by POST /search:
     * results, attempts, warnings, usage, and expires_at. No provider is called and
     * nothing is billed. Use it to look up a search by ID for debugging, cost review,
     * or to recover result IDs before calling the contents endpoint. Inline content
     * fetched at search time is included; content fetched later through the contents
     * endpoint is not merged in. Missing, expired, or inaccessible searches
     * return 404.
     *
     * @example
     * ```ts
     * const search = await client.search.retrieve('srch_abc123');
     * ```
     */
    retrieve(id, options) {
        return this._client.get(path `/search/${id}`, options);
    }
}
SearchResource.Contents = ContentsAPIContents;
SearchResource.Providers = Providers;
//# sourceMappingURL=search.mjs.map