"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Providers = void 0;
const resource_1 = require("../../core/resource.js");
/**
 * Search the web and retrieve content for selected results.
 */
class Providers extends resource_1.APIResource {
    /**
     * Lists providers, capabilities, and machine-readable native-option schemas. Auto
     * and fallback are strategies, not provider entries. The list is not paginated and
     * contains no latency benchmarks. X-Request-Id identifies the request.
     *
     * @example
     * ```ts
     * const providers = await client.search.providers.list();
     * ```
     */
    list(query = {}, options) {
        return this._client.get('/search/providers', { query, ...options });
    }
}
exports.Providers = Providers;
//# sourceMappingURL=providers.js.map