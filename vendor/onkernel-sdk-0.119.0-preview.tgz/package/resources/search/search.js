"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchResource = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const ContentsAPI = tslib_1.__importStar(require("./contents.js"));
const contents_1 = require("./contents.js");
const ProvidersAPI = tslib_1.__importStar(require("./providers.js"));
const providers_1 = require("./providers.js");
const path_1 = require("../../internal/utils/path.js");
/**
 * Search the web and retrieve content for selected results.
 */
class SearchResource extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.contents = new ContentsAPI.Contents(this._client);
        this.providers = new ProvidersAPI.Providers(this._client);
    }
    /**
     * Returns ranked results from one serving provider. The default strategy selects a
     * provider that supports the requested options. The fallback strategy tries
     * providers in the supplied order. Results are not blended across providers.
     * Portable filters may be approximated or omitted according to provider
     * capabilities; warnings describe those outcomes unless strict_params is true.
     * Native options apply only to their selected provider.
     *
     * @example
     * ```ts
     * const search = await client.search.create({ query: 'x' });
     * ```
     */
    create(body, options) {
        return this._client.post('/search', { body, ...options });
    }
    /**
     * Returns the retained search resource exactly as it was returned by POST /search:
     * results, attempts, warnings, usage, and expires_at. No provider is called and
     * nothing is billed. Use it to look up a search by ID for debugging, cost review,
     * or to recover result IDs before calling the contents endpoint. Inline content
     * fetched at search time is included; content fetched later through the contents
     * endpoint is not merged in. Missing, expired, or inaccessible searches
     * return 404.
     *
     * @example
     * ```ts
     * const search = await client.search.retrieve('srch_abc123');
     * ```
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/search/${id}`, options);
    }
}
exports.SearchResource = SearchResource;
SearchResource.Contents = contents_1.Contents;
SearchResource.Providers = providers_1.Providers;
//# sourceMappingURL=search.js.map