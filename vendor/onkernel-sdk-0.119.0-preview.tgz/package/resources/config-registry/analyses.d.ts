import { APIResource } from "../../core/resource.js";
import * as ConfigRegistryAPI from "./config-registry.js";
import { AnalysisSummariesOffsetPagination } from "./config-registry.js";
import { APIPromise } from "../../core/api-promise.js";
import { type OffsetPaginationParams, PagePromise } from "../../core/pagination.js";
import { RequestOptions } from "../../internal/request-options.js";
import { type ConfigRegistryAnalysisWaitOptions } from "../../lib/config-registry-wait.js";
/**
 * Resolve browser and proxy recommendations for bot-protected sites.
 */
export declare class Analyses extends APIResource {
    /**
     * Returns a project-scoped historical analysis and the recommendation outcome
     * concluded by that run. Later knowledge does not change this response.
     *
     * @example
     * ```ts
     * const configRegistryResponse =
     *   await client.configRegistry.analyses.retrieve('id');
     * ```
     */
    retrieve(id: string, options?: RequestOptions): APIPromise<ConfigRegistryAPI.ConfigRegistryResponse>;
    /**
     * Wait for an analysis to finish and return its complete result.
     *
     * The first retrieval happens immediately. `maxWaitMs` is a soft polling
     * deadline: an in-flight request and its normal retries may finish after it.
     * Timing out or aborting does not cancel the remote analysis.
     */
    waitForResult(id: string, options?: ConfigRegistryAnalysisWaitOptions): Promise<ConfigRegistryAPI.ConfigRegistryResponse>;
    /**
     * Lists analyses for the selected project, newest first.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const analysisSummary of client.configRegistry.analyses.list()) {
     *   // ...
     * }
     * ```
     */
    list(query?: AnalysisListParams | null | undefined, options?: RequestOptions): PagePromise<AnalysisSummariesOffsetPagination, ConfigRegistryAPI.AnalysisSummary>;
    /**
     * Requests cancellation of a running project-scoped analysis. Cancellation is
     * asynchronous; poll the analysis until its status becomes canceled. Repeating the
     * request after the analysis reaches a terminal state returns the existing
     * outcome.
     *
     * @example
     * ```ts
     * const configRegistryResponse =
     *   await client.configRegistry.analyses.cancel('id');
     * ```
     */
    cancel(id: string, options?: RequestOptions): APIPromise<ConfigRegistryAPI.ConfigRegistryResponse>;
}
export interface AnalysisListParams extends OffsetPaginationParams {
    /**
     * Case-insensitive substring search over requested URLs.
     */
    search?: string;
}
export declare namespace Analyses {
    export { type AnalysisListParams as AnalysisListParams, type ConfigRegistryAnalysisWaitOptions as ConfigRegistryAnalysisWaitOptions, };
}
export { type AnalysisSummariesOffsetPagination, type ConfigRegistryAnalysisWaitOptions };
//# sourceMappingURL=analyses.d.ts.map