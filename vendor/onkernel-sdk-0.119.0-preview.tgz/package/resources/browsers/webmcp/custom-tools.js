"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomTools = void 0;
const resource_1 = require("../../../core/resource.js");
const headers_1 = require("../../../internal/headers.js");
const path_1 = require("../../../internal/utils/path.js");
/**
 * Discover and invoke native page tools across the browser instance.
 */
class CustomTools extends resource_1.APIResource {
    /**
     * Returns every registered custom tool with its generated ID, namespace, matcher,
     * and MCP tool metadata.
     *
     * @example
     * ```ts
     * const customToolsResponse =
     *   await client.browsers.webmcp.customTools.list(
     *     'id_or_name',
     *   );
     * ```
     */
    list(idOrName, options) {
        return this._client.get((0, path_1.path) `/browsers/${idOrName}/webmcp/custom-tools`, options);
    }
    /**
     * Add a namespaced batch of custom tools. A custom tool can be page-backed or
     * CDP-backed. Page-backed tools execute in the page via JavaScript. CDP-backed
     * tools execute via CDP and can use all browser REPL tools (see `/repl`). The
     * source must evaluate to a non-empty array of definitions with URL matchers, tool
     * metadata (including an optional output schema), and execute functions. The batch
     * is added atomically. Matchers apply to top-level documents and nested frames,
     * including out-of-process iframes; each matching tool is exposed once on the
     * tab's top-level document and appears in the WebMCP tool snapshot.
     *
     * To update one tool, list the tools, delete its ID, and add its replacement. Set
     * force_overwrite_namespace to replace every existing tool in the namespace
     * atomically; omitted or false adds tools without replacing existing ones.
     * Existing invocations continue.
     *
     * @example
     * ```ts
     * const customToolsResponse =
     *   await client.browsers.webmcp.customTools.add(
     *     'id_or_name',
     *     { namespace: 'namespace', source: 'source' },
     *   );
     * ```
     */
    add(idOrName, body, options) {
        return this._client.post((0, path_1.path) `/browsers/${idOrName}/webmcp/custom-tools`, { body, ...options });
    }
    /**
     * Removes one custom tool by generated ID. An invocation already in progress is
     * not canceled.
     *
     * @example
     * ```ts
     * await client.browsers.webmcp.customTools.remove(
     *   'ct_n10b9798ad53ecc4y69z31e1',
     *   { id_or_name: 'id_or_name' },
     * );
     * ```
     */
    remove(id, params, options) {
        const { id_or_name } = params;
        return this._client.delete((0, path_1.path) `/browsers/${id_or_name}/webmcp/custom-tools/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.CustomTools = CustomTools;
//# sourceMappingURL=custom-tools.js.map