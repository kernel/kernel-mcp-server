"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Webmcp = void 0;
const tslib_1 = require("../../../internal/tslib.js");
const resource_1 = require("../../../core/resource.js");
const CustomToolsAPI = tslib_1.__importStar(require("./custom-tools.js"));
const custom_tools_1 = require("./custom-tools.js");
const path_1 = require("../../../internal/utils/path.js");
/**
 * Discover and invoke native page tools across the browser instance.
 */
class Webmcp extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.customTools = new CustomToolsAPI.CustomTools(this._client);
    }
    /**
     * Invokes the exact live registration identified by tool_ref. Non-autosubmit
     * declarative form tools return after their fields are populated with an
     * awaiting_submission status. Other tools wait for a terminal result, including
     * across navigation. Inspect a populated form, obtain any required confirmation,
     * then submit through Playwright or computer interaction without invoking the tool
     * again. If the tab or embedded frame disappears, or the request times out after
     * invocation begins, the response reports outcome_unknown and the tool is not
     * retried. CDP-backed custom tool outputs above 240 KiB return an error rather
     * than a truncated result.
     *
     * @example
     * ```ts
     * const invocationResult =
     *   await client.browsers.webmcp.invokeTool(
     *     'htzv5orfit78e1m2biiifpbv',
     *     {
     *       input: { foo: 'bar' },
     *       tool_ref: 'x',
     *     },
     *   );
     * ```
     */
    invokeTool(idOrName, body, options) {
        return this._client.post((0, path_1.path) `/browsers/${idOrName}/webmcp/invoke`, { body, ...options });
    }
    /**
     * Returns a snapshot of native and custom WebMCP tools available across every open
     * tab and embedded frame in the browser. Each tool includes an opaque tool_ref for
     * invoking that exact live registration, nested tool metadata, and source
     * information. Custom tools include their generated ID, namespace, and CDP
     * target_id in source. Tools disappear when their document closes or navigates
     * away. Use exclude_custom to return only page-provided tools.
     *
     * @example
     * ```ts
     * const toolsResponse =
     *   await client.browsers.webmcp.listTools(
     *     'htzv5orfit78e1m2biiifpbv',
     *   );
     * ```
     */
    listTools(idOrName, query = {}, options) {
        return this._client.get((0, path_1.path) `/browsers/${idOrName}/webmcp/tools`, { query, ...options });
    }
}
exports.Webmcp = Webmcp;
Webmcp.CustomTools = custom_tools_1.CustomTools;
//# sourceMappingURL=webmcp.js.map