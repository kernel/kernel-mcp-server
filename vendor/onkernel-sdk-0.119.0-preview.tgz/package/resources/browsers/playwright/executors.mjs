// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import { buildHeaders } from "../../../internal/headers.mjs";
import { path } from "../../../internal/utils/path.mjs";
/**
 * Execute Playwright code against the browser instance and manage the executors it runs in.
 */
export class Executors extends APIResource {
    /**
     * Lists the default executor first, then the named executors created by POST
     * /browsers/{id_or_name}/playwright/execute. Each entry reports whether a call is
     * running on it and, for named executors, the target ID and URL of the tab it
     * owns.
     *
     * @example
     * ```ts
     * const executorList =
     *   await client.browsers.playwright.executors.list(
     *     'htzv5orfit78e1m2biiifpbv',
     *   );
     * ```
     */
    list(idOrName, options) {
        return this._client.get(path `/browsers/${idOrName}/playwright/executors`, options);
    }
    /**
     * Stops the executor's process. A call running on it fails with an error saying
     * the executor was deleted. By default the executor's tab is closed too. The name
     * can be reused; the next call with it creates a new executor and tab.
     *
     * The default executor is restarted instead of removed: its process is stopped, a
     * call running on it fails with an error saying the executor was restarted, and
     * queued and later calls run on a new process. It owns no tab, so 'close_tab' has
     * no effect on it.
     *
     * @example
     * ```ts
     * await client.browsers.playwright.executors.delete(
     *   'checkout',
     *   { id_or_name: 'htzv5orfit78e1m2biiifpbv' },
     * );
     * ```
     */
    delete(name, params, options) {
        const { id_or_name, close_tab } = params;
        return this._client.delete(path `/browsers/${id_or_name}/playwright/executors/${name}`, {
            query: { close_tab },
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=executors.mjs.map