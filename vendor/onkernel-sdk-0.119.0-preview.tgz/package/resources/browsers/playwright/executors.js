"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Executors = void 0;
const resource_1 = require("../../../core/resource.js");
const headers_1 = require("../../../internal/headers.js");
const path_1 = require("../../../internal/utils/path.js");
/**
 * Execute Playwright code against the browser instance and manage the executors it runs in.
 */
class Executors extends resource_1.APIResource {
    /**
     * Lists the default executor first, then the named executors created by POST
     * /browsers/{id_or_name}/playwright/execute. Each entry reports whether a call is
     * running on it and, for named executors, the target ID and URL of the tab it
     * owns.
     *
     * @example
     * ```ts
     * const executorList =
     *   await client.browsers.playwright.executors.list(
     *     'htzv5orfit78e1m2biiifpbv',
     *   );
     * ```
     */
    list(idOrName, options) {
        return this._client.get((0, path_1.path) `/browsers/${idOrName}/playwright/executors`, options);
    }
    /**
     * Stops the executor's process. A call running on it fails with an error saying
     * the executor was deleted. By default the executor's tab is closed too. The name
     * can be reused; the next call with it creates a new executor and tab.
     *
     * The default executor is restarted instead of removed: its process is stopped, a
     * call running on it fails with an error saying the executor was restarted, and
     * queued and later calls run on a new process. It owns no tab, so 'close_tab' has
     * no effect on it.
     *
     * @example
     * ```ts
     * await client.browsers.playwright.executors.delete(
     *   'checkout',
     *   { id_or_name: 'htzv5orfit78e1m2biiifpbv' },
     * );
     * ```
     */
    delete(name, params, options) {
        const { id_or_name, close_tab } = params;
        return this._client.delete((0, path_1.path) `/browsers/${id_or_name}/playwright/executors/${name}`, {
            query: { close_tab },
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Executors = Executors;
//# sourceMappingURL=executors.js.map