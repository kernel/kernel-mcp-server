// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import * as ExecutorsAPI from "./executors.mjs";
import { Executors } from "./executors.mjs";
import { path } from "../../../internal/utils/path.mjs";
/**
 * Execute Playwright code against the browser instance and manage the executors it runs in.
 */
export class Playwright extends APIResource {
    constructor() {
        super(...arguments);
        this.executors = new ExecutorsAPI.Executors(this._client);
    }
    /**
     * Execute arbitrary Playwright code in a fresh execution context against the
     * browser. The code runs in the same VM as the browser, minimizing latency and
     * maximizing throughput. It has access to 'page', 'context', 'browser', and
     * 'webmcp' variables. Use 'webmcp.listTools()' to discover browser-wide WebMCP
     * tools and 'webmcp.invokeTool(toolRef, input?, { timeoutSec? })' to invoke an
     * exact registration. It can `return` a value, and this value is returned in the
     * response.
     *
     * Every call runs in an executor: a dedicated Node.js process with its own browser
     * connection. Calls on different executors run concurrently; calls on the same
     * executor run one at a time. A timeout, crash, or blocked event loop in one
     * executor does not affect other executors. After a timeout the executor keeps its
     * process and drops its browser connection, so code abandoned by the timeout
     * cannot keep driving the browser. After a crash or a blocked event loop, the next
     * call on that executor starts a fresh process.
     *
     * Calls without 'executor' run in the executor named 'default', which always
     * exists and is the same as passing 'executor: "default"'. In the default
     * executor, 'page' is bound to an active tab reported by Chrome. In single-window
     * sessions, this is the foreground tab. When multiple browser windows are open,
     * Chrome reports one active tab per window and the selected window is unspecified.
     * 'context' is the BrowserContext that owns the selected page. Use
     * 'browser.contexts()' to select a context or page explicitly.
     *
     * Pass any other name to run the call in a named executor. The first call with a
     * new name creates it. Each named executor owns a tab: its first call opens a new
     * background tab in the default browser context, and 'page' is bound to that tab
     * on every later call while it stays open. Opening it does not change the active
     * tab of an existing window. If the tab is closed, the next call opens a new one
     * and reports 'tab.created: true'. Executor code can still reach other tabs
     * through 'context' and 'browser'; ownership only decides what 'page' is bound to.
     * Use named executors to drive several tabs of one browser in parallel.
     *
     * A browser can have at most 8 named executors; the default executor does not
     * count. A call that would create another returns 409 with the current executors;
     * delete one with DELETE /browsers/{id_or_name}/playwright/executors/{name}. Named
     * executors are not removed automatically while the browser runs; when it shuts
     * down, they are removed and their tabs closed.
     *
     * @example
     * ```ts
     * const response = await client.browsers.playwright.execute(
     *   'htzv5orfit78e1m2biiifpbv',
     *   { code: 'code' },
     * );
     * ```
     */
    execute(idOrName, body, options) {
        return this._client.post(path `/browsers/${idOrName}/playwright/execute`, { body, ...options });
    }
}
Playwright.Executors = Executors;
//# sourceMappingURL=playwright.mjs.map