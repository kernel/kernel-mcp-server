export declare const VERSION = "0.119.0";
//# sourceMappingURL=version.d.mts.map