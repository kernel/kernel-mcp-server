/** @deprecated Import from ./core/api-promise instead */
export * from "./core/api-promise.mjs";
//# sourceMappingURL=api-promise.d.mts.map