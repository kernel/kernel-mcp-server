"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Items = void 0;
const resource_1 = require("../../core/resource.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Items extends resource_1.APIResource {
    /**
     * The response advertises operations that are valid in the item's current state
     * and live data that can be requested through `expand`. Read each operation's
     * description before using it. Expanded data is fetched from the provider and is
     * not persisted in the vault item. Requesting an unavailable expansion returns 409
     * instead of a partial item.
     */
    retrieve(key, params, options) {
        const { id_or_name, ...query } = params;
        return this._client.get((0, path_1.path) `/vaults/${id_or_name}/items/${key}`, { query, ...options });
    }
    /**
     * Update a card specification before or between authorizations
     */
    update(key, params, options) {
        const { id_or_name, ...body } = params;
        return this._client.patch((0, path_1.path) `/vaults/${id_or_name}/items/${key}`, { body, ...options });
    }
    /**
     * List vault items without secret values
     */
    list(idOrName, options) {
        return this._client.get((0, path_1.path) `/vaults/${idOrName}/items`, options);
    }
    /**
     * Delete a vault item and invalidate its secret value
     */
    delete(key, params, options) {
        const { id_or_name } = params;
        return this._client.delete((0, path_1.path) `/vaults/${id_or_name}/items/${key}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * List immutable audit events for a vault item
     */
    events(key, params, options) {
        const { id_or_name, ...query } = params;
        return this._client.get((0, path_1.path) `/vaults/${id_or_name}/items/${key}/events`, { query, ...options });
    }
    /**
     * Retrieve the item first and invoke only an operation listed in
     * `available_operations`, following its natural-language description. Operations
     * may call an external provider and can return the item's updated state.
     */
    performOperation(key, params, options) {
        const { id_or_name, ...body } = params;
        return this._client.post((0, path_1.path) `/vaults/${id_or_name}/items/${key}/operations`, { body, ...options });
    }
    /**
     * Create or retrieve an identical vault item by immutable key
     */
    upsert(key, params, options) {
        const { id_or_name, ...body } = params;
        return this._client.put((0, path_1.path) `/vaults/${id_or_name}/items/${key}`, { body, ...options });
    }
}
exports.Items = Items;
//# sourceMappingURL=items.js.map