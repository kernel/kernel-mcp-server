import { APIResource } from "../../core/resource.mjs";
import * as ItemsAPI from "./items.mjs";
import { AgentcardCheckoutAuthorization, CardVaultItemSpec, CardVaultItemState, ItemDeleteParams, ItemEventsParams, ItemEventsResponse, ItemListResponse, ItemPerformOperationParams, ItemRetrieveParams, ItemUpdateParams, ItemUpsertParams, Items, VaultCardAliases, VaultItem, VaultItemAction, VaultItemEvent, VaultPaymentMethod, WalletVaultItemSpec, WalletVaultItemState } from "./items.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { OffsetPagination, type OffsetPaginationParams, PagePromise } from "../../core/pagination.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Vaults extends APIResource {
    items: ItemsAPI.Items;
    /**
     * Get a vault
     */
    retrieve(idOrName: string, options?: RequestOptions): APIPromise<Vault>;
    /**
     * List vaults in the current project
     */
    list(query?: VaultListParams | null | undefined, options?: RequestOptions): PagePromise<VaultsOffsetPagination, Vault>;
    /**
     * Delete a vault and invalidate its items
     */
    delete(idOrName: string, options?: RequestOptions): APIPromise<void>;
    /**
     * Create or retrieve a vault by immutable name
     */
    upsert(body: VaultUpsertParams, options?: RequestOptions): APIPromise<Vault>;
}
export type VaultsOffsetPagination = OffsetPagination<Vault>;
export interface Vault {
    id: string;
    created_at: string;
    /**
     * Immutable name assigned when the vault is created.
     */
    name: string;
    updated_at: string;
}
export interface VaultListParams extends OffsetPaginationParams {
}
export interface VaultUpsertParams {
    /**
     * Immutable name used to create or retrieve the vault.
     */
    name: string;
}
export declare namespace Vaults {
    export { type Vault as Vault, type VaultsOffsetPagination as VaultsOffsetPagination, type VaultListParams as VaultListParams, type VaultUpsertParams as VaultUpsertParams, };
    export { Items as Items, type AgentcardCheckoutAuthorization as AgentcardCheckoutAuthorization, type CardVaultItemSpec as CardVaultItemSpec, type CardVaultItemState as CardVaultItemState, type VaultCardAliases as VaultCardAliases, type VaultItem as VaultItem, type VaultItemAction as VaultItemAction, type VaultItemEvent as VaultItemEvent, type VaultPaymentMethod as VaultPaymentMethod, type WalletVaultItemSpec as WalletVaultItemSpec, type WalletVaultItemState as WalletVaultItemState, type ItemListResponse as ItemListResponse, type ItemEventsResponse as ItemEventsResponse, type ItemRetrieveParams as ItemRetrieveParams, type ItemUpdateParams as ItemUpdateParams, type ItemDeleteParams as ItemDeleteParams, type ItemEventsParams as ItemEventsParams, type ItemPerformOperationParams as ItemPerformOperationParams, type ItemUpsertParams as ItemUpsertParams, };
}
//# sourceMappingURL=vaults.d.mts.map