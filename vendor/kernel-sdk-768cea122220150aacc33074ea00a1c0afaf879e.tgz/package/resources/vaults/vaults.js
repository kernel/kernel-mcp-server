"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Vaults = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const ItemsAPI = tslib_1.__importStar(require("./items.js"));
const items_1 = require("./items.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Vaults extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.items = new ItemsAPI.Items(this._client);
    }
    /**
     * Get a vault
     */
    retrieve(idOrName, options) {
        return this._client.get((0, path_1.path) `/vaults/${idOrName}`, options);
    }
    /**
     * List vaults in the current project
     */
    list(query = {}, options) {
        return this._client.getAPIList('/vaults', (pagination_1.OffsetPagination), { query, ...options });
    }
    /**
     * Delete a vault and invalidate its items
     */
    delete(idOrName, options) {
        return this._client.delete((0, path_1.path) `/vaults/${idOrName}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Create or retrieve a vault by immutable name
     */
    upsert(body, options) {
        return this._client.post('/vaults', { body, ...options });
    }
}
exports.Vaults = Vaults;
Vaults.Items = items_1.Items;
//# sourceMappingURL=vaults.js.map