// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as ItemsAPI from "./items.mjs";
import { Items, } from "./items.mjs";
import { OffsetPagination } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Vaults extends APIResource {
    constructor() {
        super(...arguments);
        this.items = new ItemsAPI.Items(this._client);
    }
    /**
     * Get a vault
     */
    retrieve(idOrName, options) {
        return this._client.get(path `/vaults/${idOrName}`, options);
    }
    /**
     * List vaults in the current project
     */
    list(query = {}, options) {
        return this._client.getAPIList('/vaults', (OffsetPagination), { query, ...options });
    }
    /**
     * Delete a vault and invalidate its items
     */
    delete(idOrName, options) {
        return this._client.delete(path `/vaults/${idOrName}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Create or retrieve a vault by immutable name
     */
    upsert(body, options) {
        return this._client.post('/vaults', { body, ...options });
    }
}
Vaults.Items = Items;
//# sourceMappingURL=vaults.mjs.map