// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
/**
 * Stream logs from the browser instance.
 */
export class Logs extends APIResource {
    /**
     * Stream log files on the browser instance via SSE
     *
     * @example
     * ```ts
     * const logEvent = await client.browsers.logs.stream(
     *   'htzv5orfit78e1m2biiifpbv',
     *   { source: 'path' },
     * );
     * ```
     */
    stream(idOrName, query, options) {
        return this._client.get(path `/browsers/${idOrName}/logs/stream`, {
            query,
            ...options,
            headers: buildHeaders([{ Accept: 'text/event-stream' }, options?.headers]),
            stream: true,
        });
    }
}
//# sourceMappingURL=logs.mjs.map