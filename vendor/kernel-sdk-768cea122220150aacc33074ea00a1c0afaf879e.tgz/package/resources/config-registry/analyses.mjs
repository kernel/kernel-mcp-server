// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { OffsetPagination } from "../../core/pagination.mjs";
import { path } from "../../internal/utils/path.mjs";
/**
 * Resolve browser and proxy recommendations for bot-protected sites.
 */
export class Analyses extends APIResource {
    /**
     * Returns a project-scoped historical analysis and the recommendation outcome
     * concluded by that run. Later knowledge does not change this response.
     *
     * @example
     * ```ts
     * const configRegistryResponse =
     *   await client.configRegistry.analyses.retrieve('id');
     * ```
     */
    retrieve(id, options) {
        return this._client.get(path `/config-registry/analyses/${id}`, options);
    }
    /**
     * Lists analyses for the selected project, newest first.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const analysisSummary of client.configRegistry.analyses.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
        return this._client.getAPIList('/config-registry/analyses', (OffsetPagination), { query, ...options });
    }
}
//# sourceMappingURL=analyses.mjs.map